﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace FileTransferApp
{
    public class TcpSocketServer
    {
        public int port { get; }
        public IPAddress ipAddress { get; }
        public Socket socket { get; }

        private IPEndPoint localEndPoint;

        public TcpSocketServer(int port)
        {
            if(port>1024 && port< 65535)
            {
                this.port = port;
            }
            else
            {
                port = 9501;
            }
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            this.ipAddress = ipHostInfo.AddressList[1];
            Console.WriteLine($"TCP Server Created for {ipAddress}\nPort:{port}");

            this.localEndPoint = new IPEndPoint(ipAddress, port);
            this.socket= new Socket(ipAddress.AddressFamily,
            SocketType.Stream, ProtocolType.Tcp);
        }

        public void StartServer()
        {
            try
            {
                socket.Bind(this.localEndPoint);
                socket.Listen(5);

                while(true)
                {
                    Console.WriteLine("Server is waiting for a connection.");
                    Socket handler = socket.Accept();
                    string convention = Utilities.WaitForConvention(handler);
                    Console.WriteLine("Established the following convention: " + convention);

                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    Utilities.ReceiveFileAsConvened(convention, handler);
                    watch.Stop();
                    var elapsedMs = (double)watch.ElapsedMilliseconds;

                    Console.WriteLine($"Job's Finished in {elapsedMs / 1000} seconds");
                    Console.ReadLine();
                    handler.Shutdown(SocketShutdown.Both);
                }

            }
            catch(Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }


        
    }
}
