﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace FileTransferApp
{
    public class UdpSocketServer
    {
        private Socket socket;
        public int port { get; }
        public IPAddress ipAddress { get; }

        public UdpSocketServer(int port)
        {

            if (port > 1024 && port < 65535)
            {
                this.port = port;
            }
            else
            {
                port = 9501;
            }

            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            try
            {
                this.ipAddress = ipHostInfo.AddressList[3];
            }
            catch(Exception e)
            {
                try
                {
                    this.ipAddress = ipHostInfo.AddressList[1];
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            
            Console.WriteLine($"UDP Server Created for {ipAddress}\nPort:{port}");

            this.socket= new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        }

        public void StartServer()
        {
            
            try
            {
                socket.Bind(new IPEndPoint(ipAddress, port));
                string convention = Utilities.WaitForConvention(socket);
                Console.WriteLine($"Received the following connection: {convention}");

                var watch = System.Diagnostics.Stopwatch.StartNew();
                Utilities.ReceiveFileAsConvened(convention, socket);
                watch.Stop();
                var elapsedMs = (double)watch.ElapsedMilliseconds;

                Console.WriteLine($"Job's Finished in {elapsedMs / 1000} seconds");
                Console.ReadLine();
            }
            catch(Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
    }
}
