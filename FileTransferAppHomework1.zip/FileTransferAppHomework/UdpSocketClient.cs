﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace FileTransferApp
{
    public class UdpSocketClient
    {
        public int port { get; set; }
        public IPAddress ipAddress { get; set; }
        public Socket sender { get; }

        private IPEndPoint remoteEP;

        public UdpSocketClient(IPAddress ipAddress, int port)
        {
            this.ipAddress = ipAddress;
            this.port = port;

            remoteEP = new IPEndPoint(ipAddress, port);

            sender = new Socket(ipAddress.AddressFamily,
                SocketType.Dgram, ProtocolType.Udp);
        }

        public void StartClient()
        {
            string choice_chosen = "STR";

            Console.WriteLine("Pick the sending method 1 - for stream 2 - for stop-and-wait:");
            string choice = Console.ReadLine();

            if (choice == "2")
                choice_chosen = "SAW";

            try
            {
                sender.Connect(remoteEP);

                Console.WriteLine("Socket connected to {0}",
                    sender.RemoteEndPoint.ToString());

                string filepath;
                byte[] convention;
                Utilities.SetConvention(choice_chosen, out filepath, out convention);

                sender.Send(convention);

                Utilities.SendByConvention(sender, filepath, choice_chosen);

                Console.WriteLine("I have sent the file!");

                Console.ReadLine();
            }
            catch(Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

    }
}
