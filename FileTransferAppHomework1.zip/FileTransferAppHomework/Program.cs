﻿using System;
using System.Net;

namespace FileTransferApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1.TcpServer , 2.TcpClient, 3.UdpServer, 4.UdpClient");
            var choice = Console.ReadLine();
            int port;
            string ip;
            string sPort;
            IPAddress adress;

            switch (choice)
            {
                
                case "1":
                    Console.WriteLine("TcpServer Chosen.");
                    TcpSocketServer server = new TcpSocketServer(9001);
                    server.StartServer();
                    break;
                case "2":
                    Console.WriteLine("TcpClient Chosen.");
                    Console.WriteLine("IP please:");
                    ip = Console.ReadLine();

                    Console.WriteLine("Port Please:");
                    sPort = Console.ReadLine();
                    int.TryParse(sPort, out port);
                    IPAddress.TryParse(ip, out adress);

                    TcpSocketClient client = new TcpSocketClient(adress, port);
                    client.StartClient();
                    break;
                case "3":
                    Console.WriteLine("UdpServer Chosen.");

                    UdpSocketServer uServer = new UdpSocketServer(9001);
                    uServer.StartServer();
                    break;
                case "4":
                    Console.WriteLine("UdpClient Chosen.");
                    Console.WriteLine("IP please:");
                    ip = Console.ReadLine();

                    Console.WriteLine("Port Please:");
                    sPort = Console.ReadLine();
                    int.TryParse(sPort, out port);
                    IPAddress.TryParse(ip, out adress);

                    UdpSocketClient uclient = new UdpSocketClient(adress, port);
                    uclient.StartClient();
                    break;
            }

        }
    }
}
