﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;

namespace FileTransferApp
{
    public class Utilities
    {
        public static string WaitForConvention(Socket handler)
        {
            string convention = "";
            byte[] bytes = new Byte[1024];

            bool conventionSet = false;

            while (!conventionSet)
            {
                int bytesRec = handler.Receive(bytes);
                convention += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                if (convention.IndexOf("<EOF>") > -1)
                {
                    conventionSet = true;
                }
                if (convention.Length > 1000)
                    break;
            }

            return convention;
        }

        public static void SetConvention(string choice_chosen, out string filepath, out byte[] convention)
        {
            Console.WriteLine("Select a file to send.");

            filepath = Console.ReadLine();
            var filename = Path.GetFileName(filepath);
            FileInfo fileinfo = new FileInfo(filepath);

            int filesize = (int)fileinfo.Length;

            Console.WriteLine($"Sending Convention is: {choice_chosen};{filename};{filesize};");

            convention = Encoding.ASCII.GetBytes($"{choice_chosen};{filename};{filesize};<EOF>");
        }


        public static void SendByConvention(Socket sender,string filepath, string mode)
        {
            using (Stream source = File.OpenRead(filepath))
            {
                byte[] buffer = new byte[2048];
                byte[] confirmation = new byte[100];
                int bytesRead;
                int packagesSent = 0;
                int totalBytesSent = 0;

                while ((bytesRead = source.Read(buffer, 0, buffer.Length)) > 0)
                {
                    if (mode == "STR")
                    {
                        sender.Send(buffer,bytesRead,SocketFlags.None);
                        packagesSent++;
                        totalBytesSent += buffer.Length;
                    }
                    else
                    {
                        sender.Send(buffer, bytesRead, SocketFlags.None);
                        int bytesRec = sender.Receive(confirmation);
                        string data = "";
                        data += Encoding.ASCII.GetString(confirmation, 0, bytesRec);
                        packagesSent++;
                        totalBytesSent += buffer.Length;

                        int retry = 10;

                        while (data != "ok" && retry > 0)
                        {
                            Console.WriteLine("Confirmation not received, retring");
                            bytesRec = sender.Receive(confirmation);
                            data += Encoding.ASCII.GetString(confirmation, 0, bytesRec);
                            retry--;
                        }
                    }
                }
                Console.WriteLine("Total packages sent:" + packagesSent.ToString());
                Console.WriteLine("Total bytes sent:" + totalBytesSent.ToString());
            }

        }


        public static void ReceiveFileAsConvened(string convention, Socket handler)
        {
            try
            {
                var rules = convention.Split(';');
                var method = rules[0];
                var filename = rules[1];
                int filesize = 0;
                int.TryParse(rules[2], out filesize);

                if (method.Equals("SAW"))
                {
                    StopAndWaitReceive(handler, filename, filesize);
                }
                if (method.Equals("STR"))
                {
                    StreamReceive(handler, filename, filesize);
                }
                Console.WriteLine("Job's done.");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        public static void StopAndWaitReceive(Socket handler, string filename, int filesize)
        {
            int totalBytesReceived = 0;
            int totalPackages = 0;

            byte[] bytes = new Byte[10240];



            while (filesize > 0)
            {
                int bytesRec = handler.Receive(bytes);
                if (bytesRec > 0)
                {
                    ByteArrayToFile(filename, bytes, bytesRec);
                    totalBytesReceived += bytesRec;
                    totalPackages++;
                    filesize -= bytesRec;
                    handler.Send(Encoding.ASCII.GetBytes("ok"));
                }

            }
            Console.WriteLine("Total Bytes Received: " + totalBytesReceived.ToString());
            Console.WriteLine("Total Packages Received: " + totalPackages.ToString());
        }

        public static void StreamReceive(Socket handler, string filename, int filesize)
        {
            int totalBytesReceived = 0;
            int totalPackages = 0;

            byte[] bytes = new Byte[10240];



            while (filesize > 0)
            {
                int bytesRec = handler.Receive(bytes);
                if (bytesRec > 0)
                {
                    ByteArrayToFile(filename, bytes, bytesRec);
                    filesize -= bytesRec;
                    totalPackages++;
                    totalBytesReceived += bytesRec;
                }

            }
            Console.WriteLine("Total Bytes Received: " + totalBytesReceived.ToString());
            Console.WriteLine("Total Packages Received: " + totalPackages.ToString());
        }

        public static void ByteArrayToFile(string fileName, byte[] byteArray, int length)
        {
            try
            {
                using (var fs = new FileStream(fileName, FileMode.Append, FileAccess.Write))
                {
                    fs.Write(byteArray, 0, length);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught in process: {0}", ex);
            }
        }
    }
}
