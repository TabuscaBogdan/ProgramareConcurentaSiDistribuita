#Author:Tabusca Bogdan
import socket
import os
import sys
import tkinter as tk
from tkinter import filedialog

def pick_path_file():
    #for file picking
    root = tk.Tk()
    root.withdraw()
    file_path = tk.filedialog.askopenfilename()
    return file_path
def pick_path_folder():
    root = tk.Tk()
    root.withdraw()
    folder_path = tk.filedialog.askdirectory()
    return folder_path

def optimum_split(path):
    op1=path.split('\\')
    op2=path.split('/')
    if(len(op1)>len(op2)):
        return op1[-1]
    return op2[-1]
def get_size(path):
    try:
        size=os.path.getsize(path)
        return size
    except:
        print("something went wrong with the size of the file (worng path maybe)")
        return 0
def get_myip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ip= s.getsockname()[0]
    s.close()
    return ip
print("Your ip is: "+get_myip())


def progressBar(value, endvalue, bar_length=20):
    percent = float(value) / endvalue
    arrow = '-' * int(round(percent * bar_length) - 1) + '>'
    spaces = ' ' * (bar_length - len(arrow))

    sys.stdout.write("\rPercent: [{0}] {1}%".format(arrow + spaces, int(round(percent * 100))))
    sys.stdout.flush()
#def progressBar_reciver(value,bar_length=20):
#    arrow = '-' * int(round(value * bar_length) - 1) + '>'
#    spaces = ' ' * (bar_length - len(arrow))
#    sys.stdout.write("\rPercent: [{0}] {1}%".format(arrow + spaces, int(round(percent * 100))))
#    sys.stdout.flush()


#Server for reciving files:
def server_reciver():
    print("Give me a path to the folder where your file should be placed...")
    #for IDE---
    #to_folder=input("Path=")
    #----------
    #for users---
    to_folder=pick_path_folder()
    #------------
    print("The file will be placed in->",to_folder)
    srv_sock=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    m_ip=get_myip()
    try:
        srv_sock.bind((m_ip, 8783))
    except socket.error as msg:
        print('Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1])
        sys.exit()
    srv_sock.listen(4)
    #-------------------------
    while 1:
        # wait to accept a connection - blocking call
        conn, addr = srv_sock.accept()
        print('Connected with ' + addr[0] + ':' + str(addr[1]))
        conn.send("Conn estabilsed, ready for transfer!".encode('utf-8'))
        size=conn.recv(1024)
        #----------
        name_size=conn.recv(128)
        conn.send('ok'.encode('utf-8'))
        name_size=int(name_size)
        print(name_size)
        #----------
        size=size.decode('utf-8')
        size=int(size)
        #----------
        #size=int(size)
        file_name=conn.recv(1024)
        print(file_name)
        print("File to recive:"+file_name.decode("utf-8", "ignore"))
        file = open(to_folder+'\\'+file_name.decode("utf-8", "ignore")[:name_size],'wb')

        view_size=size

        completed=0
        while(size>1):
            progressBar(completed,view_size)
            pack=conn.recv(1024)
            no_bytes_recived=len(pack)
            #---For debugging---
            #print(no_bytes_recived)
            #de sync here
            #-------------------
            file.write(pack)
            size=size-no_bytes_recived
            completed=view_size-size

        else:
            print("Finished.")
            file.close()
            srv_sock.close()
            break

def client_sender():
    print("Give me a file to send...")

    #for users--
    path_f=pick_path_file()
    #------------
    #for console
    #path_f=input("Path=")
    #-----------
    print(path_f," Was chosen")
    file_size=get_size(path_f)
    file=open(path_f,'rb')
    print("To whom shal I send it to?")
    dest_ip=input("Destination Ip adress=")
    #------------------------------------
    cli_socket=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    cli_socket.connect((str(dest_ip), 8783))
    msg=cli_socket.recv(1024)
    print(msg)
    #---
    cli_socket.send(str(file_size).encode('utf-8'))
    #---
    #---
    fname=optimum_split(path_f)
    #---
    #lungimea numelui
    cli_socket.send(str(len(fname)).encode('utf-8'))
    cli_socket.recv(4)
    #---
    cli_socket.send(fname.encode('utf-8'))

    view_size = int(file_size / 1024)
    curent_size = 0
    while(file_size>0):
        progressBar(curent_size, view_size)
        pack=file.read(1024)
        cli_socket.sendall(pack)
        file_size=file_size-1024
        curent_size+=1
    else:
        print("Finished.")
        file.close()
        cli_socket.close()

#For sending to receivers who are behind a Router
def server_sender():
    print("Select your file that you wish for the other party to download...")
    #for users--
    path_f=pick_path_file()
    #------------
    #for console
    #path_f=input("Path=")
    #-----------
    print("The file to be shared is->",path_f)
    file_size=get_size(path_f)
    file=open(path_f,'rb')
    fname = optimum_split(path_f)

    srv_sock=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    m_ip=get_myip()
    try:
        srv_sock.bind((m_ip, 8783))
    except socket.error as msg:
        print('Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1])
        sys.exit()
    srv_sock.listen(4)
    #-------------------------
    while 1:
        conn, addr = srv_sock.accept()
        print('Connected with ' + addr[0] + ':' + str(addr[1]))
        conn.send("Conn estabilsed, ready for transfer!".encode('utf-8'))
        conn.recv(4)
        #----------------------------------------------------------
        conn.send(str(file_size).encode('utf-8'))
        # lungimea numelui
        conn.send(str(len(fname)).encode('utf-8'))
        conn.recv(4)
        # ---
        # ---trimite numele
        conn.send(fname.encode('utf-8'))
        #-------------
        view_size = int(file_size / 1024)
        curent_size = 0
        while (file_size > 0):
            progressBar(curent_size, view_size)
            pack = file.read(1024)
            conn.sendall(pack)
            file_size = file_size - 1024
            curent_size += 1
        else:
            print("Finished.")
            file.close()
            conn.close()

def client_reciver():
    print("Give me a path to the folder where your file should be placed...")
    #for IDE---
    #to_folder=input("Path=")
    #----------
    #for users---
    to_folder=pick_path_folder()
    #------------
    print("From who shall I receive a file?")
    dest_ip = input("Destination Ip adress=")
    # ------------------------------------
    cli_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    cli_socket.connect((str(dest_ip), 8783))
    msg=cli_socket.recv(1024)
    print(msg)
    #---
    cli_socket.sendall('ok'.encode('utf-8'))

    size = cli_socket.recv(1024)
    # ----------
    name_size = cli_socket.recv(128)
    cli_socket.send('ok'.encode('utf-8'))
    name_size = int(name_size)
    print(name_size)
    # ----------
    size = size.decode('utf-8')
    size = int(size)
    # ----------
    # size=int(size)
    file_name = cli_socket.recv(1024)
    print(file_name)
    print("File to recive:" + file_name.decode("utf-8", "ignore"))
    file = open(to_folder + '\\' + file_name.decode("utf-8", "ignore")[:name_size], 'wb')

    view_size = size

    completed = 0
    while (size > 1):
        progressBar(completed, view_size)
        pack = cli_socket.recv(1024)
        no_bytes_recived = len(pack)
        # ---For debugging---
        # print(no_bytes_recived)
        # de sync here
        # -------------------
        file.write(pack)
        size = size - no_bytes_recived
        completed = view_size - size
    else:
        print("Finished.")
        file.close()
        cli_socket.close()


print("Do you want to Send a file or Receive a file?")
print("(1:Send,2:Receive,3:Post to Send<For your hidden friend>,4:Hidden Receive<Use this if you are behind a router>)")
choice=input("Choice =")
if int(choice)==1:
    try:
        client_sender()
    except TimeoutError:
        print("Other party Failed to respond <if they are behind a router try again with choice 3 and them with choice 4>")
    except:
        print("Connection was refused")

elif int(choice)==2:
    server_reciver()
elif int(choice)==3:
    server_sender()
else:
    client_reciver()

input("Press Enter to Exit.")



