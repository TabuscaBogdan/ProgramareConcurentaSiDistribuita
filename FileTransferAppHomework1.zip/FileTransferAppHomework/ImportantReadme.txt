Continut:
-Clasele cs + csproj
- FastFileTransferer.py (BACKUP)

Instructiuni:
1.Ruleaza comanda 'dotnet publish -c Release -r ubuntu.16.10-x64'
  pentru a crea dll-urile si pachetele pentru linux
2.Pe linux instaleaza .net core 2.0 sdk
3.Ruleaza pe linux din folderul de publish comanda:
  'dotnet FileTransfererApp.dll'

Pot aparea erori in functie de la
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            this.ipAddress = ipHostInfo.AddressList[1];
Pentru ca depinde de pe ce retea rulezi, de pe ce os, fin ip-urile in ordine
diferite si pot fi mai multe sau mai putine.
(Daca nu si nu ruleaza scriptul de python, are doar tcp dar merge sigur)

PS:E ultima oara cand fac appuri de .netcore pt linux

Statistici:(Stick net 21Mbs,FileSize:388.888kb)

Tcp(Stream):Total Bytes sent:398221312
            Total packages sent:194444
            Total Bytes Received: 398220642
            Total Packages Received: 38890
            Time: 82.041
            
Tcp(Stop&Wait):Total Bytes sent:398221312
               Total packages sent:194444
               Total Bytes Received:398221311
               Total Packages Received: 38839
               Time: ~5min


Udp:(fails)(on both accounts)